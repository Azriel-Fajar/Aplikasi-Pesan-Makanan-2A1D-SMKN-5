package com.example.mefood;

public class RestoranData {
    private String nama, gambar, alamat, telp, jadwal_buka, jam_buka, deskripsi;



    public String getNama(){
        return nama;
    }
    public String getGambar(){
        return gambar;
    }
    public String getAlamat(){
        return alamat;
    }
    public String getTelp(){
        return telp;
    }
    public String getDeskripsi() {
        return  deskripsi;
    }
    public String getJadwal(){
        return jadwal_buka;
    }
    public String getJam(){
        return jam_buka;
    }


}
