package com.example.mefood;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button login = findViewById(R.id.login);
        Button signup = findViewById(R.id.signup);
        ImageView google = findViewById(R.id.google);
        ImageView facebook = findViewById(R.id.facebook);
        ImageView twitter = findViewById(R.id.twitter);
        ImageView instagram = findViewById(R.id.instagram);

        EditText user = findViewById(R.id.user);
        EditText pw = findViewById(R.id.password);





        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve the username from the EditText
                String username = user.getText().toString().trim();
                String pass = pw.getText().toString().trim();
                ConnectivityManager connectivityManager=(ConnectivityManager)
                        getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();



                if (username.isEmpty()) {
                    // If the username is empty, show an error message
                    user.setError("Please enter username");

                } else if (pass.isEmpty()) {
                    pw.setError("Please enter your password");
                } else if ( networkInfo != null && networkInfo.isConnected()) {


                    // Show a toast with the entered username
                    Toast.makeText(MainActivity.this, "Successfully Login as " + username, Toast.LENGTH_SHORT).show();
                    // Start PesanActivity and pass the username
                    Intent intent = new Intent(MainActivity.this, PesanActivity.class);
                    intent.putExtra("user", username);
                    startActivity(intent);
                }
               else {
                    Toast.makeText(MainActivity.this, "Tidak terhubung ke internet", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });

        google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Coming Soon", Toast.LENGTH_SHORT).show();
            }
        });

        facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Coming Soon", Toast.LENGTH_SHORT).show();
            }
        });

        twitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Coming Soon", Toast.LENGTH_SHORT).show();
            }
        });

        instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Coming Soon", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
