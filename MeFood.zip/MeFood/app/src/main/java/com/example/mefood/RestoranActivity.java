package com.example.mefood;

import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;


public class RestoranActivity extends AppCompatActivity {
    private TextView nama_restoran, alamat_restoran, telp_restoran, deskripsi_restoran, jadwal_restoran, jam_restoran;
    private ImageView gambar_restoran;
    private Button btn;




    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restoran);

        nama_restoran = findViewById(R.id.nama_restoran);
        gambar_restoran = findViewById(R.id.gambar_restoran);
        alamat_restoran = findViewById(R.id.alamat_restoran);
        telp_restoran = findViewById(R.id.telp_restoran);
        deskripsi_restoran = findViewById(R.id.deskripsi_restoran);
        jadwal_restoran = findViewById(R.id.jadwal_buka);
        jam_restoran = findViewById(R.id.jam_buka);

        btn = findViewById(R.id.btn_ke_pesan);



        try {
            AssetManager assetManager = getAssets();
            InputStream inputStream = assetManager.open("Data.JSON");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();

            String json = new String(buffer, StandardCharsets.UTF_8);

            RestoranData restoranData = new Gson().fromJson(json, RestoranData.class);

            nama_restoran.setText(restoranData.getNama());
            alamat_restoran.setText(restoranData.getAlamat());
            telp_restoran.setText(restoranData.getTelp());
            deskripsi_restoran.setText(restoranData.getDeskripsi());
            jadwal_restoran.setText(restoranData.getJadwal());
            jam_restoran.setText(restoranData.getJam());


            String urlGambar = restoranData.getGambar();

            Glide.with(this).load(urlGambar).into(gambar_restoran);

        } catch (IOException e) {
            e.printStackTrace();
        }
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  new Intent(RestoranActivity.this, ListMenu.class);
                startActivity(intent);
            }
        });


    }
}
