package com.example.mefood;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class SecondActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        EditText inputUSER = findViewById(R.id.input_user);
        EditText inputEMAIL = findViewById(R.id.input_email);
        EditText inputPASSWORD = findViewById(R.id.input_pw);
        EditText inputCHECKPASSWORD = findViewById(R.id.input_cpw);



        Button sign_up = findViewById(R.id.sign_up);

        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String USER = inputUSER.getText().toString().trim();
                String EMAIL = inputEMAIL.getText().toString().trim();
                String PASSWORD = inputPASSWORD.getText().toString().trim();
                String CHECKPASSWORD = inputCHECKPASSWORD.getText().toString().trim();

                if (USER.isEmpty()){
                    inputUSER.setError("Username required!");
                } else if (EMAIL.isEmpty()){
                    inputEMAIL.setError("Email required!");
                } else if (PASSWORD.isEmpty()) {
                    inputPASSWORD.setError("Password Required!");
                } else if (CHECKPASSWORD.isEmpty()){
                    inputCHECKPASSWORD.setError("Write your password again!");
                } else if (!PASSWORD.equals(CHECKPASSWORD)){
                    inputPASSWORD.setError("Password don't match!");
                    inputCHECKPASSWORD.setError("Password don't match");
                } else {
                    Toast.makeText(SecondActivity.this, "Successfully Login as " + USER, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SecondActivity.this, PesanActivity.class);
                    intent.putExtra("user", USER);
                    startActivity(intent);
                }
            }
        });
    }




}

